package imgprocessor.model.flipper;

/**
 * Extends the AFlipper class.
 * Flips an image vertically.
 */
public class VertFlipperImpl extends AFlipper{

}
