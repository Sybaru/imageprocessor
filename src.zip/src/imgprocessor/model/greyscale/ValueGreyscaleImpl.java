package imgprocessor.model.greyscale;

/**
 * Extends the AGreyscale abstract class.
 * Converts an image into greyscale using the highest component of rgb.
 */
public class ValueGreyscaleImpl extends AGreyscale{

}
